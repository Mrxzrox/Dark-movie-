package com.flixclusive.feature.mobile.player.controls.common.slider.util

internal enum class ColorSchemeKeyTokens {
    OnPrimary,
    OnSurface,
    OnSurfaceVariant,
    Primary,
    Surface,
    SurfaceVariant,
}