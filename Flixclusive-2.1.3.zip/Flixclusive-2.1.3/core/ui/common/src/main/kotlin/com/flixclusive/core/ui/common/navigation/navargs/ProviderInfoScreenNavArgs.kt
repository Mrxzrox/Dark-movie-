package com.flixclusive.core.ui.common.navigation.navargs

import com.flixclusive.model.provider.ProviderData

data class ProviderInfoScreenNavArgs(
    val providerData: ProviderData
)