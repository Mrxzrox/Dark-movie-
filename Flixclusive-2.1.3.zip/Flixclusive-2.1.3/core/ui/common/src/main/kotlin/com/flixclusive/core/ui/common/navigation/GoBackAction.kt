package com.flixclusive.core.ui.common.navigation

interface GoBackAction {
    fun goBack()
}