package com.flixclusive.core.ui.common.navigation.navargs

import com.flixclusive.model.provider.Catalog


data class SeeAllScreenNavArgs(
    val item: Catalog
)