package com.flixclusive.core.ui.common.navigation

interface StartHomeScreenAction : GoBackAction {
    fun openHomeScreen()
}