package com.flixclusive.core.ui.common.navigation.navargs

import com.flixclusive.model.film.Genre

data class GenreScreenNavArgs(
    val genre: Genre,
)