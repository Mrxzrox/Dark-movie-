package com.flixclusive.core.ui.common.navigation.navigator

import com.flixclusive.model.provider.ProviderData

interface ProviderTestNavigator {
    fun testProviders(providers: ArrayList<ProviderData>)
}